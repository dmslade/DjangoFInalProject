from django.http import HttpResponseRedirect
from django.shortcuts import redirect, render, get_object_or_404

class ObjectDeleteMixin:
    model = None
    success_url = ''
    template_name = ''

    def get(self, request, pk):
        obj = get_object_or_404(
            self.model, pk=pk)
        context = {
            self.model.__name__.lower(): obj,
        }
        return render(
            request, self.template_name, context)

    def post(self, request, pk):
        obj = get_object_or_404(
            self.model, pk=pk)
        obj.delete()
        return HttpResponseRedirect(
            self.success_url)