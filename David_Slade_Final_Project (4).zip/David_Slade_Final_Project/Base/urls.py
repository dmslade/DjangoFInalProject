from django.urls import path, include
from .views import post, home, showAll, image, delete # Login, DisableAccount, ActivateAccount, CreateAccount , ProfileDetail, ProfileUpdate 
#from django.contrib.staticfiles.urls import static

urlpatterns = [
	#path("",homePage, name="home"),
	path("",home,name="index"),
	path("post", post, name="post"),
	path("showAll/",showAll,name="all_images"),
	path("image",image,name="image"),
	path("delete",delete,name="delete")
]