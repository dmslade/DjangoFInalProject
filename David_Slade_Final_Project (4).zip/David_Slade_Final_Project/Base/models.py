from django.db import models
from django.conf import settings
from django.contrib.auth.models import User
from django.template.defaultfilters import slugify
from django.urls import reverse

# Create your models here.


class Post(models.Model):
    #user = models.ForeignKey(User)
    title = models.CharField(max_length=128)
    body = models.CharField(max_length=400)
  
def get_image_filename(instance, filename):
    title = instance.post.title
    slug = slugify(title)
    return "post_images/%s-%s" % (slug, filename)  

#class Album(models.Model):   
#   category = models.ForeignKey(Category, related_name='albums')

class Images(models.Model):
    post = models.ForeignKey(Post, default=None, on_delete=models.DO_NOTHING)
    image = models.ImageField(upload_to=get_image_filename,
                              verbose_name='Image')

#    album = models.ForeignKey(Album)




#class Image(models.Model):
#    title  = models.CharField(max_length=200)
#    image = models.ImageField(upload_to='images')

#    def __str__(self):
#        return self.title