from django.shortcuts import render
from django.forms import modelformset_factory
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import HttpResponseRedirect
from .forms import ImageForm, PostForm
from .models import Images
import os 
from django.contrib.auth.views import LoginView, LogoutView
from django.contrib.auth.forms import AuthenticationForm

#@login_required
def post(request):
 
    ImageFormSet = modelformset_factory(Images,
                                        form=ImageForm, extra=4)
    if request.method == 'POST':
    
        postForm = PostForm(request.POST)
        formset = ImageFormSet(request.POST, request.FILES,
                               queryset=Images.objects.none())
    
    
        if postForm.is_valid() and formset.is_valid():
            post_form = postForm.save(commit=False)
            post_form.user = request.user
            post_form.save()
        
            for form in formset.cleaned_data:
                if form:
                    image = form['image']
                    photo = Images(post=post_form, image=image)
                    photo.save()
            messages.success(request,
                             "Success in submiting the images that you want to upload.")
            return HttpResponseRedirect("/")
        else:
            print(postForm.errors, formset.errors)
    else:
        postForm = PostForm()
        formset = ImageFormSet(queryset=Images.objects.none())
    return render(request, 'pritucre.html',
                  {'postForm': postForm, 'formset': formset})
    
#def login(request, template_name='')

# Create your views here.
#def upload_image(request):
#    if request.method =='POST':
#        form = ImageForm(request.POST,request.FILES)
#        if form.is_valid():
#            form.save()
#            return redirect('home')
#    else:
#        form = ImageForm()
#    return render(request, 'u')


def home(request):
    return render(request, "index.html")

class Login(LoginView):
    template_name = 'login.html'
    authentication_form = AuthenticationForm

def showAll(request):
    context_dict = {}
    files = os.listdir(r"C:\Users\dmsla\OneDrive\Desktop\Django\David_Slade_Final_Project\post_images") #change this to your own path
    context_dict['files'] = files
    return render(request, 'gallery.html', context=context_dict)

def image(request):
    return render(request,"gallery.html")

def delete(request):
    context_dict = {}
    files = os.listdir(r"C:\Users\dmsla\OneDrive\Desktop\Django\David_Slade_Final_Project\post_images") 
    context_dict['files'] = files
    for images in files:
        if images.endswith(".png"):
            os.remove(os.path.join(r"C:\Users\dmsla\OneDrive\Desktop\Django\David_Slade_Final_Project\post_images",images))
    return render(request, 'gallery_confrim_delete.html', context=context_dict)

def clear(request):
    return render(request,"gallery_confrim_delete.html")