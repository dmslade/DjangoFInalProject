from django.contrib import admin

# Register your models here.
from Base import models

admin.site.register(models.Images)
admin.site.register(models.Post)
