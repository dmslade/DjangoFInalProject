from django.urls import include, path,reverse_lazy
from django.contrib.auth.views import LoginView,LogoutView
from django.contrib.auth.forms import \
    AuthenticationForm
from django.views.generic import RedirectView, TemplateView
from .views import Login, DisableAccount, ActivateAccount, CreateAccount , ProfileDetail, ProfileUpdate
from django.contrib.auth import views as auth_views

app_name = 'user'
#sitepath/user/login

password_urls = [
    path("change/",auth_views.PasswordChangeView.as_view(),{'template_name':
            'user/password_change_form.html',
         'post_change_redirect': reverse_lazy(
            'dj-auth:pw_change_done')},name = 'pw_change'),
    path("change/done/",auth_views.PasswordChangeDoneView.as_view(),{'template_name':
            'user/password_change_done.html'}, name= 'pw_change_done'),
    path('reset/',
        auth_views.PasswordResetView.as_view(),
        {'template_name':
            'user/password_reset_form.html',
         'email_template_name':
            'user/password_reset_email.txt',
         'subject_template_name':
            'user/password_reset_subject.txt',
         'post_reset_redirect': reverse_lazy(
            'dj-auth:pw_reset_sent')},
        name='pw_reset_start'),
    path('reset/sent/',
        auth_views.PasswordResetDoneView.as_view(),
        {'template_name':
            'user/password_reset_sent.html'},
        name='pw_reset_sent'),
    path('reset/<uidb64>/<token>',
        auth_views.PasswordResetConfirmView.as_view(),
        {'template_name':
            'user/password_reset_confirm.html',
         'post_reset_redirect': reverse_lazy(
            'dj-auth:pw_reset_complete')},
        name='pw_reset_confirm'),
    path('reset/done/',
        auth_views.PasswordResetCompleteView.as_view(),
        {'template_name':
            'user/password_reset_complete.html',
         'extra_context':
             {'form': AuthenticationForm}},
        name='pw_reset_complete'),
]

urlpatterns=[
    path('',RedirectView.as_view( pattern_name='dj-auth:login',permanent=False)),
    path('login/',Login.as_view(), name='login'),
    path('logout/',LogoutView.as_view(),{'template_name': 'user/logged_out.html','extra_context':
             {'form': AuthenticationForm}},
        name='logout'),
    path("disable/",DisableAccount.as_view(), name= 'disable'),
    path("password/",include(password_urls)),
    path("activate/<uidb64>/<token>",ActivateAccount.as_view(),name= "activate"),
    path("create/",CreateAccount.as_view(), name= "create"),
    path("create/done",TemplateView.as_view(template_name=
            'user/user_create_done.html'),name= "create_done"),
    path("profile/", ProfileDetail.as_view(), name='profile' ),
    path("profile/edit", ProfileUpdate.as_view(), name='profile_update')
   
]