from django.conf import settings
from django.db import models
from django.urls import reverse
from django.contrib.auth.models import (
    AbstractBaseUser,BaseUserManager,
    PermissionsMixin)
    
# Create your models here.
class Profile(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,on_delete=models.DO_NOTHING)
    name = models.CharField(
        max_length=255)
    slug = models.SlugField(
        max_length=30,
        unique=True)
    about = models.TextField()
    joined = models.DateTimeField(
        "Date Joined",
        auto_now_add=True)

    def __str__(self):
        return self.user.get_username()

    def get_absolute_url(self):
        return reverse(
            'dj-auth:public_profile',
            kwargs={'slug': self.slug})

    def get_update_url(self):
        return reverse('dj-auth:profile_update')